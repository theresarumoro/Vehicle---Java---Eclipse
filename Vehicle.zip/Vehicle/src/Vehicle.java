
class Vehicle {
	
	//create members
	String Type;
	int NumberOfWheels;
	float EngineSize;
	boolean UsesGasoline;
	
	//sets the type of vehicle given variable data of type String
	public void setType(String typeOfVehicle) {
		Type = typeOfVehicle;
	}

	//sets the number of wheels for vehicle
	public void setNumberOfwheels(int numWheels) {
		NumberOfWheels = numWheels;
	}
	
	//sets the engine size of the vehicle
	public void setEngineSize(float engineSize) {
		EngineSize = engineSize;
	}
	
	//sets if the vehicle uses gasoline
	public void setUsesGasoline(boolean useGasoline) {
		UsesGasoline = useGasoline;
	}

	//get type of vehicle
	public String getType() {
		return Type;
	}
	
	//get number of wheels of vehicle
	public int getNumberOfWheels() {
		return NumberOfWheels;
	}
	
	//get engine size of vehicle
	public float getEngineSize() {
		return EngineSize;
	}
	
	//get if vehicle uses gasoline
	public boolean getUsesGasoline() {
		return UsesGasoline;
	}
	
	public Vehicle() {
	}
	
	//displays vehicle information
	public void print() {
		System.out.println(" ");									//print space
		System.out.println("Type: " + Type);						//print type
		System.out.println("Number of wheels: " + NumberOfWheels);	//print number of wheels
		System.out.println("Engine Size: " + EngineSize);			//print engine size
		//uses if else statement to see if the vehicle uses gasoline
		//if false, print no
		//else, print yes
		if (UsesGasoline != true) {
			System.out.println("Uses gasoline: No");
		}
		else {
			System.out.println("Uses gasoline: Yes");
		}
	}

	//main function
	public static void main(String[] args) {
	
		//sets mybicycle information to members
		Vehicle mybicycle = new Vehicle();	//creates mybicycle as a new vehicle
		mybicycle.setType("Bicycle");		//sets type to Bicycle
		mybicycle.setNumberOfwheels(2);		//sets wheels to 2
		mybicycle.setEngineSize(0.0f);		//sets engine size to 0.0f
		mybicycle.setUsesGasoline(false);	//sets uses gasoline to false

		//sets mycar information to members
		Vehicle mycar = new Vehicle();	//creates mycar as a new vehicle
		mycar.setType("Nissan");		//sets type to Nissan
		mycar.setNumberOfwheels(4);		//sets wheels to 4
		mycar.setEngineSize(3.5f);		//sets engine size to 3.5f
		mycar.setUsesGasoline(true);	//sets uses gasoline to true

		//sets mytruck information to members
		Vehicle mytruck = new Vehicle();	//creates mytruck as a new vehicle
		mytruck.setType("Semi Truck");		//sets type to Semi Truck
		mytruck.setNumberOfwheels(18);		//sets wheels to 18
		mytruck.setEngineSize(5.3f);		//sets engine size to 5.3f
		mytruck.setUsesGasoline(true);		//sets uses gasoline to true

		//sets myunicycle information to members
		Vehicle myunicycle = new Vehicle();	//creates myunicycle as a new vehicle
		myunicycle.setType("Unicycle");		//sets type to Unicycle
		myunicycle.setNumberOfwheels(1);	//sets wheels to 1
		myunicycle.setEngineSize(0.0f);		//sets engine size to 0.0f
		myunicycle.setUsesGasoline(false);	//sets uses gasoline to false

		//creates an array, myVehicles, with mybicycle, mycar, mytruck, and myunicycle
		Vehicle[] myVehicles = {mybicycle, mycar, mytruck, myunicycle};

		//goes through array variables to send to the print
		//function, which then displays the information to
		//the user
		for (int i=0; i<4; i++) {
			myVehicles[i].print();
		}
	}
}
